export interface Session {
  data?: any;
  error?: any;
}
