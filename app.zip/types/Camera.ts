export interface Camera {
  image: string;
  name: string;
  key: string;
}
