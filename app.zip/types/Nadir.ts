export interface Nadir {
  image: string;
  url: string;
}
